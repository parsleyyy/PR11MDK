﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR11.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        double[] mass = new double[16];
        double[] d = new double[16];
        public Page1()
        {
            InitializeComponent();
        }

        private void btnCrt_Click(object sender, RoutedEventArgs e)
        {
            btnCrt.Content = "Пересоздать массив";
            LstInput1.Items.Clear();
            Random rand = new Random();
            for (int i = 0; i < 16; i++)
            {
                mass[i] = rand.Next(-10, 10);
                LstInput1.Items.Add($"{i + 1})  X[{i}]={mass[i]}");
            }
            
        }

        private void btnResult_Click(object sender, RoutedEventArgs e)
        {
            if (LstInput1.Items.Count > 0)
            {
                LstInput2.Items.Clear();
                for (int i = 0; i < 16; i++)
                {
                    d[i] = Math.Round((Math.Pow(2.72, mass[i]) + 2 * Math.Pow(2.72, -mass[i])) / (Math.Sqrt(5 + Math.Sin(mass[i]))), 5);
                    if (d[i] < 0.1)
                        d[i] = 0;
                    LstInput2.Items.Add($"{i + 1})  d[{i}]={d[i]}");
                }
            }
            else
            {
                MessageBox.Show("Заполните исходный массив!", "Уведомление!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void btnClearAll_Click(object sender, RoutedEventArgs e)
        {
            LstInput1.Items.Clear();
            LstInput2.Items.Clear();
        }
    }
}
